"""Release adapters reject invalid certificates and compare real public APIs."""

import io
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

import networkx as nx
import pytest

from benchmarks.release_worker import validate_pcstp


def objective(graph, total, prizes, edges, nodes):
    return (
        sum(graph[u][v]["weight"] for u, v in edges)
        + total
        - sum(prizes.get(n, 0) for n in nodes)
    )


@pytest.mark.parametrize(
    "edges,nodes,value",
    [
        ([(1, 2)], [1], 5),
        ([(1, 2), (2, 1)], [1, 2], 4),
        ([], [1, 3], 0),
        ([(1, 2)], [1, 2], 99),
    ],
)
def test_pcstp_rejects_invalid_certificate(edges, nodes, value):
    graph = nx.Graph()
    graph.add_weighted_edges_from([(1, 2, 2), (2, 3, 2)])
    with pytest.raises(ValueError):
        validate_pcstp(graph, {1: 5, 3: 5}, edges, nodes, value, objective)


def test_pcstp_allows_empty_or_single_vertex_tree():
    graph = nx.path_graph([1, 2, 3])
    assert validate_pcstp(graph, {1: 5, 3: 5}, [], [], 10, objective) == 10
    assert validate_pcstp(graph, {1: 5, 3: 5}, [], [1], 5, objective) == 5


@pytest.fixture
def run_worker(tmp_path):
    root = Path(__file__).resolve().parents[1]
    archive = subprocess.check_output(
        [
            "git",
            "-C",
            str(root),
            "archive",
            "--format=zip",
            "v1.1.0",
            "steinerpy",
            "benchmarks/pace2018.py",
            "benchmarks/stp_parser.py",
            "benchmarks/__init__.py",
            "benchmark_pcstp.py",
        ]
    )
    source = tmp_path / "tag-source"
    with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
        bundle.extractall(source)

    def run(method, experiment="api_parity"):
        instance = tmp_path / "tiny.stp"
        terminals = "TP 1 5\nTP 3 5" if experiment == "pcstp" else "T 1\nT 3"
        instance.write_text(
            "SECTION Graph\nNodes 3\nEdges 3\nE 1 2 1\nE 2 3 1\nE 1 3 5\nEND\n"
            "SECTION Terminals\nTerminals 2\n" + terminals + "\nEND\nEOF\n"
        )
        progress = tmp_path / (method + ".json")
        request = tmp_path / (method + "-request.json")
        request.write_text(
            json.dumps(
                dict(
                    case=dict(
                        experiment=experiment,
                        method=method,
                        solver="highs",
                        source_root=str(source),
                        path=str(instance),
                        seed=0,
                        reference_lower=2,
                        reference_upper=2,
                    ),
                    config="highs",
                    time_limit=20,
                    memory_gb=8,
                    progress=str(progress),
                )
            )
        )
        env = dict(
            os.environ,
            PYTHONHASHSEED="0",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            STEINERPY_THREADS="1",
            STEINERPY_DECOMPOSE="0",
            STEINERPY_DW_MAX_TERMINALS="10",
        )
        subprocess.run(
            [
                sys.executable,
                str(root / "benchmarks/release_worker.py"),
                "--worker",
                str(request),
            ],
            cwd=tmp_path,
            env=env,
            check=True,
            timeout=30,
        )
        return json.loads(progress.read_text())

    return run


def test_public_api_parity_in_fresh_processes(run_worker):
    root = Path(__file__).resolve().parents[1]
    results = [run_worker(method) for method in ("legacy", "modular")]
    assert [r["objective"] for r in results] == [2, 2]
    for row in results:
        assert row["feasible"] and row["solver_proven_optimal"]
        assert row["total_seconds"] >= row["constructor_seconds"] >= 0
        assert row["model_build_seconds"] == 0  # preprocessing solves this fixture
        assert (
            Path(row["steinerpy_import_path"]).parent
            == Path(row["source_root"]) / "steinerpy"
        )
        assert Path(row["source_root"]) != root


@pytest.mark.parametrize("method", ["kou", "mehlhorn"])
def test_networkx_certificates_are_checked_without_solver_proof(run_worker, method):
    row = run_worker(method, "steinlib")
    assert row["feasible"] and row["objective"] == 2
    assert row["reference_optimal"] and not row["solver_proven_optimal"]
    assert row["gap"] is None


@pytest.mark.parametrize("method", ["exact", "heuristic"])
def test_pcstp_without_competitor_dependency(run_worker, method):
    row = run_worker(method, "pcstp")
    assert row["feasible"] and row["objective"] == row["reported_objective"] == 2
    assert row["solution_edges"] and set(row["solution_nodes"]) == {1, 2, 3}
    assert row["solver_seconds"] is None
