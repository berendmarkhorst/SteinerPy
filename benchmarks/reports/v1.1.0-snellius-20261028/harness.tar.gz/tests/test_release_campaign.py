"""Freeze release identity, isolate cases, and preserve resumable array work."""

import argparse
from contextlib import contextmanager
import json
from types import SimpleNamespace
import pytest

from benchmarks import release_campaign as campaign
from benchmarks.pace2018 import execute_case


def test_source_tampering_and_untracked_python_are_rejected(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    module = source / "module.py"
    module.write_text("value = 1\n")
    hashes = {"module.py": campaign.file_hash(module)}
    campaign.verify_source(source, hashes)
    module.write_text("value = 2\n")
    with pytest.raises(ValueError, match="snapshot was modified"):
        campaign.verify_source(source, hashes)
    module.write_text("value = 1\n")
    (source / "shadow.py").write_text("value = 3\n")
    with pytest.raises(ValueError, match="unexpected Python"):
        campaign.verify_source(source, hashes)


def test_tag_must_resolve_to_pinned_commit(tmp_path, monkeypatch):
    monkeypatch.setattr(
        campaign.subprocess, "check_output", lambda *a, **k: "main-commit\n"
    )
    with pytest.raises(ValueError, match="pinned release commit"):
        campaign.source_export(tmp_path)
    assert not (tmp_path / "source").exists()


def test_resume_rejects_changed_release_harness_or_software(tmp_path, monkeypatch):
    monkeypatch.setattr(campaign, "harness_hashes", lambda: {"runner.py": "good"})
    monkeypatch.setattr(campaign, "software", lambda: {"python": "3.12.3"})
    manifest = dict(
        tag=campaign.TAG,
        commit=campaign.COMMIT,
        harness={"runner.py": "good"},
        software={"python": "3.12.3"},
        source_root=str(tmp_path),
        source_files={},
    )
    campaign.verify_campaign(manifest)
    for field, changed in (
        ("tag", "main"),
        ("commit", "other"),
        ("harness", {"runner.py": "changed"}),
        ("software", {"python": "3.13.0"}),
    ):
        with pytest.raises(ValueError):
            campaign.verify_campaign(dict(manifest, **{field: changed}))


def test_environment_changes_for_hardware_allocation_and_versions_not_job_id(
    monkeypatch,
):
    monkeypatch.setenv("SLURM_JOB_ID", "original-job")
    monkeypatch.setenv("SLURM_MEM_PER_NODE", "8192")
    monkeypatch.setattr(
        campaign.subprocess, "check_output", lambda *a, **k: "TimeLimit=01:00:00\n"
    )
    monkeypatch.setattr(campaign.sys, "platform", "win32")
    monkeypatch.setattr(campaign.platform, "processor", lambda: "CPU A")
    monkeypatch.setattr(
        campaign, "software", lambda: {"python": "3.12", "packages": {"highspy": "1.8"}}
    )
    manifest = dict(settings=dict(threads=1, memory_gb=8, time_limit=30), harness={})
    first = campaign.digest(campaign.environment(manifest))
    monkeypatch.setenv("SLURM_JOB_ID", "new-job")
    monkeypatch.setenv("SLURM_ARRAY_TASK_ID", "22")
    assert campaign.digest(campaign.environment(manifest)) == first
    monkeypatch.setattr(campaign.platform, "processor", lambda: "CPU B")
    assert campaign.digest(campaign.environment(manifest)) != first
    monkeypatch.setattr(campaign.platform, "processor", lambda: "CPU A")
    monkeypatch.setenv("SLURM_MEM_PER_NODE", "16384")
    assert campaign.digest(campaign.environment(manifest)) != first
    monkeypatch.setenv("SLURM_MEM_PER_NODE", "8192")
    monkeypatch.setattr(
        campaign, "software", lambda: {"python": "3.12", "packages": {"highspy": "1.9"}}
    )
    assert campaign.digest(campaign.environment(manifest)) != first


def test_array_shards_are_disjoint_and_keep_parity_pairs_together(tmp_path):
    args = argparse.Namespace(smoke=True, solvers=["highs", "gurobi"], parity_repeats=2)
    cases = campaign.make_cases(args, tmp_path, tmp_path / "source")
    groups = campaign.units(dict(cases=cases))
    assert groups == campaign.units(dict(cases=cases))
    shards = [groups[index::7] for index in range(7)]
    identifiers = [
        case["case_id"] for shard in shards for group in shard for case in group
    ]
    assert len(identifiers) == len(cases) == len(set(identifiers))
    for group in groups:
        if group[0]["experiment"] == "api_parity":
            assert len(group) == 2
            assert {case["method"] for case in group} == {"legacy", "modular"}
            for field in (
                "path",
                "instance_sha256",
                "solver",
                "repeat",
                "seed",
                "unit_id",
            ):
                assert group[0][field] == group[1][field]


@pytest.mark.parametrize(
    "method,solver,slots",
    [
        ("exact", "highs", 0),
        ("exact", "gurobi", 1),
        ("dual_ascent", "gurobi", 2),
    ],
)
def test_run_creates_environment_and_resumes_only_matching_results(
    tmp_path, monkeypatch, method, solver, slots
):
    source = tmp_path / "instance.stp"
    source.write_text("an instance")
    case = dict(
        case_id="one",
        unit_id="one",
        experiment="steinlib",
        path=str(source),
        instance_sha256=campaign.file_hash(source),
        method=method,
        solver=solver,
    )
    manifest = dict(
        cases=[case],
        source_root=str(tmp_path),
        settings=dict(time_limit=30, memory_gb=8, threads=1),
    )
    campaign.write_json(tmp_path / "manifest.json", manifest)
    monkeypatch.setattr(campaign, "verify_campaign", lambda manifest: None)
    monkeypatch.setattr(
        campaign,
        "environment",
        lambda manifest: dict(cpu="CPU A", manifest_sha256=campaign.digest(manifest)),
    )
    calls = []
    lease_events = []

    @contextmanager
    def fake_slot(directory, time_limit):
        index = len(lease_events)
        lease_events.append(("acquire", index))
        yield {"used": True, "refresh": lambda: lease_events.append(("refresh", index))}
        lease_events.append(("release", index))

    @contextmanager
    def fake_lock(path):
        path.parent.mkdir(parents=True, exist_ok=True)
        yield

    if solver == "gurobi":
        monkeypatch.setattr(
            campaign, "os", SimpleNamespace(name="posix", environ=campaign.os.environ)
        )
        monkeypatch.setattr(campaign, "file_lock", fake_lock)
        monkeypatch.setattr(campaign, "wls_slot", fake_slot)

    def execute(case, options, identity, directory, destination, name):
        assert lease_events == (
            [("acquire", i) for i in range(slots)]
            + [("refresh", i) for i in range(slots)]
        )
        calls.append(name)
        campaign.write_json(destination, dict(case, status="optimal", run=identity))

    monkeypatch.setattr(campaign, "execute_case", execute)
    args = argparse.Namespace(
        jobs=1, shard_index=0, shard_count=2, license_slots=tmp_path / "slots"
    )
    campaign.run(args, tmp_path)
    assert list((tmp_path / "environments").glob("*.json"))
    campaign.run(args, tmp_path)
    assert calls == ["one"]
    stored = campaign.result_path(tmp_path, case)
    result = campaign.read_json(stored)
    result["run"]["manifest_sha256"] = "different-campaign"
    campaign.write_json(stored, result)
    with pytest.raises(ValueError, match="does not match"):
        campaign.run(args, tmp_path)
    assert calls == ["one"]


def test_script_worker_timeout_discards_unreturned_objective(tmp_path):
    script = tmp_path / "worker.py"
    script.write_text(
        "import json, os, pathlib, sys, time\n"
        "request = json.loads(pathlib.Path(sys.argv[2]).read_text())\n"
        "row = dict(request['case'], status='running', feasible=True, objective=1, gap=0, "
        "solver_proven_optimal=True, env_ok=all(os.environ[k] == '1' for k in "
        "('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','STEINERPY_THREADS')))\n"
        "pathlib.Path(request['progress']).write_text(json.dumps(row))\n"
        "time.sleep(30)\n"
    )
    directory = tmp_path / "case"
    directory.mkdir()
    args = argparse.Namespace(
        config="highs",
        time_limit=1.0,
        memory_gb=1,
        worker_script=script,
        source_root=tmp_path,
    )
    result_path = directory / "result.json"
    result = execute_case(
        dict(case_id="timeout"),
        args,
        dict(commit=campaign.COMMIT),
        directory,
        result_path,
        "timeout",
    )
    assert result["status"] == "timeout" and result["feasible"] is False
    assert result["env_ok"] is True
    assert "objective" not in result and "solver_proven_optimal" not in result
    assert result["wall_seconds"] < 10
    assert json.loads(result_path.read_text()) == result
