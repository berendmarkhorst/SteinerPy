"""Release reports must preserve incomplete work and comparable API pairs."""

import csv
import json

import pytest

from benchmarks.release_report import load_rows, parity_pairs, summarize


def case(method="legacy", **overrides):
    row = dict(
        case_id=method,
        experiment="api_parity",
        dataset="B",
        instance="b01",
        instance_sha256="input",
        method=method,
        solver="highs",
        repeat=0,
        seed=0,
    )
    row.update(overrides)
    return row


def result(method="legacy", env="one", **overrides):
    row = dict(
        case(method),
        status="optimal",
        feasible=True,
        objective=4.0,
        solver_proven_optimal=True,
        total_seconds=1.0 if method == "legacy" else 1.1,
        wall_seconds=2.0,
        run=dict(environment_id=env, commit="tagged"),
    )
    row.update(overrides)
    return row


def write_campaign(root, cases, results):
    (root / "manifest.json").write_text(
        json.dumps(
            dict(tag="v1.1.0", mode="smoke", commit="tagged", cases=cases, settings={})
        )
    )
    for row in results:
        path = root / row["experiment"] / "raw" / row["case_id"] / "result.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(row))


def test_parity_mismatches_are_not_timing_evidence():
    pairs = parity_pairs([result(), result("modular", objective=5.0)])
    assert pairs[0]["flag"] == "OBJECTIVE_MISMATCH"
    assert "total_seconds_percent" not in pairs[0]
    pairs = parity_pairs([result(), result("modular", feasible=False, status="error")])
    assert pairs[0]["flag"] == "FEASIBILITY_MISMATCH"
    pairs = parity_pairs([result(solver_proven_optimal=False), result("modular")])
    assert pairs[0]["flag"] == "match"
    assert "total_seconds_percent" not in pairs[0]


def test_hardware_and_versions_are_never_paired_across_environments():
    pairs = parity_pairs([result(), result("modular", env="two")])
    assert len(pairs) == 2
    assert all(pair["flag"] == "incomplete" for pair in pairs)
    pair = parity_pairs([result(), result("modular")])[0]
    assert pair["flag"] == "match_optimal"
    assert pair["total_seconds_percent"] == pytest.approx(10)
    assert pair["total_seconds_delta"] == pytest.approx(0.1)


def test_summary_includes_pending_cases_and_can_regenerate(tmp_path):
    write_campaign(tmp_path, [case(), case("modular")], [result()])
    rows = summarize(tmp_path)
    assert len(rows) == 2 and rows[1]["status"] == "pending"
    report = tmp_path / "api_parity" / "summary.md"
    assert "Pending: 1" in report.read_text(encoding="utf-8")
    assert "Smoke results validate the workflow only" in report.read_text(
        encoding="utf-8"
    )
    write_campaign(tmp_path, [case(), case("modular")], [result(), result("modular")])
    summarize(tmp_path)
    with (tmp_path / "api_parity" / "results.csv").open(
        newline="", encoding="utf-8"
    ) as stream:
        exported = list(csv.DictReader(stream))
    assert len(exported) == 2 and all(
        row["parity_flag"] == "match_optimal" for row in exported
    )
    assert exported[0]["run_commit"] == "tagged"
    for experiment in ("pace", "api_parity", "steinlib", "pcstp"):
        assert (tmp_path / experiment / "results.csv").exists()
        assert (tmp_path / experiment / "summary.md").exists()


@pytest.mark.parametrize(
    "overrides",
    [
        dict(instance_sha256="changed"),
        dict(run=dict(environment_id="one", commit="main")),
        dict(case_id="orphan"),
    ],
)
def test_mixed_or_orphan_results_are_rejected(tmp_path, overrides):
    write_campaign(tmp_path, [case()], [result(**overrides)])
    with pytest.raises(ValueError, match="manifest"):
        load_rows(tmp_path)


def test_pcstp_reference_requires_a_checked_exact_proof(tmp_path):
    exact = case("exact", experiment="pcstp", case_id="exact", dataset="JMP")
    heuristic = case(
        "heuristic", experiment="pcstp", case_id="heuristic", dataset="JMP"
    )
    exact_result = dict(
        exact,
        status="feasible",
        feasible=True,
        objective=4,
        solver_proven_optimal=False,
        run=dict(environment_id="one", commit="tagged"),
    )
    heuristic_result = dict(
        heuristic,
        status="feasible",
        feasible=True,
        objective=5,
        run=dict(environment_id="one", commit="tagged"),
    )
    write_campaign(tmp_path, [exact, heuristic], [exact_result, heuristic_result])
    assert all("reference_gap" not in row for row in summarize(tmp_path))
    exact_result.update(status="optimal", solver_proven_optimal=True)
    write_campaign(tmp_path, [exact, heuristic], [exact_result, heuristic_result])
    assert summarize(tmp_path)[1]["reference_gap"] == pytest.approx(0.25)
