"""Regenerate release CSVs and Markdown from immutable per-case JSON results."""

import argparse
from collections import defaultdict
import csv
from datetime import datetime, timezone
import io
import json
import math
from pathlib import Path
import statistics
import uuid

EXPERIMENTS = ("pace", "api_parity", "steinlib", "pcstp")
SUCCESS = {"optimal", "feasible"}


def atomic_text(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        temporary.write_text(value, encoding="utf-8")
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def load_rows(root):
    """Keep pending work explicit and reject results outside the frozen manifest."""
    root = Path(root)
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    expected = {}
    for case in manifest["cases"]:
        key = (case["experiment"], case["case_id"])
        if key in expected or case["experiment"] not in EXPERIMENTS:
            raise ValueError("Duplicate or unknown manifest case: {}".format(key))
        expected[key] = dict(case, status="pending", run={})
    for experiment in EXPERIMENTS:
        for path in sorted((root / experiment / "raw").glob("*/result.json")):
            result = json.loads(path.read_text(encoding="utf-8"))
            key = (experiment, path.parent.name)
            if key not in expected:
                raise ValueError("Result outside manifest: {}".format(path))
            case = expected[key]
            for field in (
                "case_id",
                "experiment",
                "instance",
                "instance_sha256",
                "method",
                "solver",
                "repeat",
                "seed",
                "dataset",
                "track",
            ):
                if field in case and result.get(field) != case[field]:
                    raise ValueError(
                        "Result differs from manifest: {} {}".format(key, field)
                    )
            run = result.get("run", {})
            if not run.get("environment_id"):
                raise ValueError("Result lacks environment_id: {}".format(key))
            if "commit" in run and run["commit"] != manifest["commit"]:
                raise ValueError("Result commit differs from manifest: {}".format(key))
            for field in ("time_limit", "memory_gb", "threads"):
                if field in run and run[field] != manifest.get("settings", {}).get(
                    field
                ):
                    raise ValueError(
                        "Result limits differ from manifest: {} {}".format(key, field)
                    )
            expected[key] = result
    return manifest, list(expected.values())


def finite(value):
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


def valid(row):
    return (
        row.get("feasible") is True
        and row.get("status") in SUCCESS
        and finite(row.get("objective"))
    )


def proven(row):
    return valid(row) and (
        row.get("solver_proven_optimal") is True or row.get("reference_optimal") is True
    )


def environment(row):
    return row.get("run", {}).get("environment_id", "pending")


def median(values):
    numbers = [value for value in values if finite(value)]
    return statistics.median(numbers) if numbers else None


def fmt(value):
    return "—" if value is None else "{:.5g}".format(value)


def parity_pairs(rows):
    """Compare identical randomized cases only within one recorded environment."""
    grouped = defaultdict(dict)
    for row in rows:
        key = tuple(
            row.get(field)
            for field in (
                "dataset",
                "track",
                "instance",
                "instance_sha256",
                "solver",
                "repeat",
                "seed",
            )
        ) + (environment(row),)
        method = row["method"]
        if method in grouped[key]:
            raise ValueError(
                "Duplicate API parity measurement: {} {}".format(key, method)
            )
        grouped[key][method] = row
    pairs = []
    for key, methods in grouped.items():
        legacy, modular = methods.get("legacy"), methods.get("modular")
        pair = dict(
            environment_id=key[-1],
            solver=key[4],
            instance=key[2],
            repeat=key[5],
            flag="incomplete",
        )
        if (
            legacy
            and modular
            and all(row["status"] != "pending" for row in (legacy, modular))
        ):
            feasibility_mismatch = legacy.get("feasible") != modular.get("feasible")
            objective_mismatch = all(
                finite(row.get("objective")) for row in (legacy, modular)
            ) and not math.isclose(
                legacy["objective"], modular["objective"], rel_tol=1e-9, abs_tol=1e-6
            )
            flags = []
            if feasibility_mismatch:
                flags.append("FEASIBILITY_MISMATCH")
            if objective_mismatch:
                flags.append("OBJECTIVE_MISMATCH")
            pair["flag"] = (
                "+".join(flags)
                if flags
                else (
                    "match"
                    if all(valid(row) for row in (legacy, modular))
                    else "unavailable"
                )
            )
            if pair["flag"] == "match" and all(
                proven(row) for row in (legacy, modular)
            ):
                pair["flag"] = "match_optimal"
                for field in ("total_seconds", "wall_seconds"):
                    baseline, candidate = legacy.get(field), modular.get(field)
                    if finite(baseline) and finite(candidate) and baseline > 0:
                        pair[field + "_delta"] = candidate - baseline
                        pair[field + "_percent"] = 100 * (candidate / baseline - 1)
        for row in methods.values():
            row["parity_flag"] = pair["flag"]
        pairs.append(pair)
    return pairs


def write_csv(rows, path):
    preferred = [
        "case_id",
        "experiment",
        "dataset",
        "track",
        "instance",
        "method",
        "solver",
        "repeat",
        "seed",
        "status",
        "feasible",
        "objective",
        "gap",
        "solver_proven_optimal",
        "reference_optimal",
        "reference_gap",
        "parity_flag",
        "total_seconds",
        "constructor_seconds",
        "model_build_seconds",
        "solver_seconds",
        "wall_seconds",
        "worker_seconds",
        "peak_rss_mb",
        "environment_id",
        "instance_sha256",
        "finished_utc",
        "error",
    ]
    flattened = []
    for row in rows:
        result = {key: value for key, value in row.items() if key != "run"}
        result["environment_id"] = environment(row)
        result.update(
            {"run_" + key: value for key, value in row.get("run", {}).items()}
        )
        # Preserve certificates, nested package metadata, and future metrics losslessly.
        flattened.append(
            {
                key: (
                    json.dumps(value, sort_keys=True, allow_nan=False)
                    if isinstance(value, (dict, list))
                    else value
                )
                for key, value in result.items()
            }
        )
    columns = preferred + sorted(
        {key for row in flattened for key in row} - set(preferred)
    )
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=columns)
    writer.writeheader()
    writer.writerows(flattened)
    atomic_text(path, stream.getvalue())


def add_reference_gaps(rows):
    """Use published optima, or checked exact PCSTP proofs; never a timeout incumbent."""
    optima = {}
    for row in rows:
        key = (
            environment(row),
            row.get("dataset"),
            row["instance"],
            row["instance_sha256"],
        )
        if row["experiment"] == "pcstp" and row["method"] == "exact" and proven(row):
            previous = optima.get(key)
            if previous is not None and not math.isclose(
                previous, row["objective"], rel_tol=1e-9, abs_tol=1e-6
            ):
                raise ValueError("Conflicting checked PCSTP optima: {}".format(key))
            optima[key] = row["objective"]
    for row in rows:
        if not valid(row):
            continue
        opt = None
        if row.get("reference_lower") == row.get("reference_upper") and finite(
            row.get("reference_upper")
        ):
            opt = row["reference_upper"]
        elif row["experiment"] == "pcstp":
            key = (
                environment(row),
                row.get("dataset"),
                row["instance"],
                row["instance_sha256"],
            )
            opt = optima.get(key)
        if opt is not None:
            row["reference_gap"] = (
                (row["objective"] - opt) / abs(opt)
                if opt
                else (0.0 if abs(row["objective"]) <= 1e-6 else None)
            )


def summary_text(manifest, experiment, rows, pairs):
    lines = [
        "# {} — {}".format(manifest["tag"], experiment),
        "",
        "Mode: **{}**. Commit: `{}`. Generated: {}.".format(
            manifest["mode"], manifest["commit"], datetime.now(timezone.utc).isoformat()
        ),
        "",
        "Expected: {}. Finished: {}. Pending: {}.".format(
            len(rows),
            sum(row["status"] != "pending" for row in rows),
            sum(row["status"] == "pending" for row in rows),
        ),
        "",
        "Each environment ID identifies its recorded software, hardware and limits; environments are never pooled. See `../environment.json` and `../environments/`.",
        "",
        "| Environment | Dataset/track | Method | Solver | Expected | Feasible | Proven/reference optimal | Timeout | Failed/unavailable | Pending | Median wall s | Median reference gap % |",
        "|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    groups = defaultdict(list)
    for row in rows:
        dataset = str(row.get("dataset", "")) + (
            " / " + str(row["track"]) if row.get("track") is not None else ""
        )
        groups[(environment(row), dataset, row["method"], row["solver"])].append(row)
    for key, group in sorted(groups.items()):
        successful = [row for row in group if valid(row)]
        pending = sum(row["status"] == "pending" for row in group)
        timeouts = sum(row["status"] == "timeout" for row in group)
        values = list(key) + [
            str(len(group)),
            str(len(successful)),
            str(sum(proven(row) for row in group)),
            str(timeouts),
            str(len(group) - len(successful) - pending - timeouts),
            str(pending),
            fmt(median(row.get("wall_seconds") for row in successful)),
            fmt(
                median(
                    100 * row["reference_gap"]
                    for row in successful
                    if finite(row.get("reference_gap"))
                )
            ),
        ]
        lines.append("| " + " | ".join(values) + " |")
    lines += [
        "",
        "Medians describe checked feasible results only; failures and pending work remain in the counts. Reference gaps use published optima or checked exact PCSTP proofs within the same environment. Missing certificates or timings remain blank in CSV.",
    ]
    if experiment == "pace":
        lines += [
            "",
            "Track 2 tree-decomposition files are not consumed by SteinerPy. Published PACE bounds are quality references, not same-hardware timing measurements.",
        ]
    if experiment == "api_parity":
        lines += [
            "",
            "## API parity",
            "",
            "Only pairs with the same input checksum, solver, seed, repetition and environment are compared. Runtime overhead uses matching, independently feasible, proven/reference-optimal pairs. `total_seconds` measures constructor plus solution call; wall time also includes process startup, imports and parsing.",
            "",
            "| Environment | Solver | Pair status | Count | Median total delta s | Median total overhead % | Median wall delta s | Median wall overhead % |",
            "|---|---|---|---:|---:|---:|---:|---:|",
        ]
        paired_groups = defaultdict(list)
        for pair in pairs:
            paired_groups[
                (pair["environment_id"], pair["solver"], pair["flag"])
            ].append(pair)
        for key, group in sorted(paired_groups.items()):
            values = (
                list(key)
                + [str(len(group))]
                + [
                    fmt(median(pair.get(field) for pair in group))
                    for field in (
                        "total_seconds_delta",
                        "total_seconds_percent",
                        "wall_seconds_delta",
                        "wall_seconds_percent",
                    )
                ]
            )
            lines.append("| " + " | ".join(values) + " |")
        mismatches = [pair for pair in pairs if "MISMATCH" in pair["flag"]]
        lines += [
            "",
            "Objective/feasibility mismatches: **{}**. All flags are retained per measurement in `results.csv`.".format(
                len(mismatches)
            ),
        ]
        for pair in mismatches[:20]:
            lines.append(
                "- `{}` / {} / repetition {} / `{}`: **{}**".format(
                    pair["instance"],
                    pair["solver"],
                    pair["repeat"],
                    pair["environment_id"],
                    pair["flag"],
                )
            )
        lines += [
            "",
            "Interpretation: a median total overhead above both 5% and 0.01 s is a descriptive signal to investigate. This is not a significance test; repeated measurements and a representative completed dataset are required before concluding meaningful API overhead. Incomplete or cross-environment pairs do not support timing conclusions.",
        ]
    if manifest["mode"] == "smoke":
        lines += [
            "",
            "**Smoke results validate the workflow only; they do not establish benchmark performance or API overhead.**",
        ]
    return "\n".join(lines) + "\n"


def summarize(root):
    root = Path(root)
    manifest, rows = load_rows(root)
    add_reference_gaps(rows)
    pairs = parity_pairs([row for row in rows if row["experiment"] == "api_parity"])
    for experiment in EXPERIMENTS:
        selected = [row for row in rows if row["experiment"] == experiment]
        write_csv(selected, root / experiment / "results.csv")
        atomic_text(
            root / experiment / "summary.md",
            summary_text(manifest, experiment, selected, pairs),
        )
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    summarize(parser.parse_args().output)
