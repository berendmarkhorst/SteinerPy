"""Immutable v1.1.0 campaign: prepare, run/resume, and summarize.

The harness is an overlay; every measured import comes from a verified git archive.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager, ExitStack
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import io
import json
import math
import os
from pathlib import Path
import platform
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from benchmarks.pace2018 import execute_case, reference_cases, wls_slot, write_json
from benchmarks.optima import load_optima, optimum_for

TAG = "v1.1.0"
COMMIT = "ef7265ee646ebd9f6b47635d68a2a4b7ee590200"
RELEASE = ROOT / "benchmarks" / "releases" / TAG
PACKAGES = (
    "steinerpy",
    "networkx",
    "numpy",
    "scipy",
    "highspy",
    "gurobipy",
    "pcst_fast",
)
HARNESS = (
    "release_campaign.py",
    "release_worker.py",
    "release_report.py",
    "pace2018.py",
    "optima.py",
    "slurm_release_v1_1_0.sh",
)
WORKER_ENV = dict(
    PYTHONHASHSEED="0",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    NUMEXPR_NUM_THREADS="1",
    BLIS_NUM_THREADS="1",
    VECLIB_MAXIMUM_THREADS="1",
    STEINERPY_THREADS="1",
    STEINERPY_SEP_THREADS="1",
    STEINERPY_REDUCE_JOBS="1",
    STEINERPY_ASCENT_JOBS="1",
    STEINERPY_DECOMPOSE="0",
    STEINERPY_DW_MAX_TERMINALS="10",
    STEINERPY_NESTED_CUTS="1",
    STEINERPY_LP_CUT_ROUNDS="50",
    STEINERPY_CUT_PURGE_AGE="0",
)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def file_hash(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


@contextmanager
def file_lock(path):
    """OS-owned locks survive neither process exit nor node failure; no stale leases."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as stream:
        if os.name == "nt":
            import msvcrt

            stream.write(b"\0")
            stream.flush()
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(stream, fcntl.LOCK_EX)
        try:
            yield
        finally:
            if os.name == "nt":
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream, fcntl.LOCK_UN)


def source_export(output):
    revision = subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", TAG + "^{commit}"], text=True
    ).strip()
    if revision != COMMIT:
        raise ValueError("v1.1.0 tag does not resolve to the pinned release commit")
    archive = subprocess.check_output(
        ["git", "-C", str(ROOT), "archive", "--format=zip", COMMIT]
    )
    source = output / "source"
    source.mkdir(parents=True, exist_ok=True)
    hashes = {}
    with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
        for entry in bundle.infolist():
            if entry.is_dir():
                continue
            path = source / entry.filename
            if not path.resolve().is_relative_to(source.resolve()):
                raise ValueError("unsafe git archive path")
            content = bundle.read(entry)
            hashes[entry.filename] = hashlib.sha256(content).hexdigest()
            if path.exists():
                if file_hash(path) != hashes[entry.filename]:
                    raise ValueError("tag snapshot was modified: " + str(path))
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(content)
    verify_source(source, hashes)
    write_json(
        output / "source-manifest.json", dict(tag=TAG, commit=COMMIT, files=hashes)
    )
    return source, hashes


def verify_source(source, hashes):
    for name, expected in hashes.items():
        if not (source / name).is_file() or file_hash(source / name) != expected:
            raise ValueError("tag snapshot was modified: " + name)
    extra = {
        p.relative_to(source).as_posix() for p in source.rglob("*.py")
    } - hashes.keys()
    if extra:
        raise ValueError(
            "unexpected Python files in tag snapshot: " + repr(sorted(extra))
        )


def versions():
    result = {}
    for package in PACKAGES:
        try:
            result[package] = metadata.version(package)
        except metadata.PackageNotFoundError:
            result[package] = None
    return result


def software():
    engines = {}
    if versions()["highspy"]:
        import highspy

        engines["highs"] = highspy.Highs().version()
    if versions()["gurobipy"]:
        import gurobipy

        engines["gurobi"] = ".".join(map(str, gurobipy.gurobi.version()))
    return dict(
        python=platform.python_version(),
        implementation=platform.python_implementation(),
        packages=versions(),
        engines=engines,
    )


def harness_hashes():
    return {name: file_hash(ROOT / "benchmarks" / name) for name in HARNESS}


def environment(manifest):
    cpu = platform.processor()
    if sys.platform == "linux":
        cpu = next(
            (
                line.split(":", 1)[1].strip()
                for line in Path("/proc/cpuinfo").read_text().splitlines()
                if line.startswith("model name")
            ),
            cpu,
        )
    slurm_walltime = None
    if os.environ.get("SLURM_JOB_ID"):
        try:
            details = subprocess.check_output(
                ["scontrol", "show", "job", "-o", os.environ["SLURM_JOB_ID"]],
                text=True,
                timeout=15,
            )
            slurm_walltime = next(
                item.split("=", 1)[1]
                for item in details.split()
                if item.startswith("TimeLimit=")
            )
        except (OSError, subprocess.SubprocessError, StopIteration):
            pass
    return dict(
        software(),
        tag=TAG,
        commit=COMMIT,
        steinerpy_version="1.1.0",
        cpu=cpu,
        platform=platform.platform(),
        machine=platform.machine(),
        allocated_memory_mb=os.environ.get("SLURM_MEM_PER_NODE"),
        allocated_memory_per_cpu_mb=os.environ.get("SLURM_MEM_PER_CPU"),
        allocated_cpus=os.environ.get("SLURM_CPUS_PER_TASK"),
        slurm_partition=os.environ.get("SLURM_JOB_PARTITION"),
        slurm_walltime=slurm_walltime,
        requested_slurm_walltime=os.environ.get("CAMPAIGN_SLURM_WALLTIME"),
        memory_limit_enforced=sys.platform == "linux",
        settings=manifest["settings"],
        harness_sha256=digest(manifest["harness"]),
        manifest_sha256=digest(manifest),
    )


def fixture_data(output):
    """Two deterministic STPs and a prize fixture, never scientific data."""
    import random

    folder = output / "fixtures"
    folder.mkdir(exist_ok=True)
    graph = "SECTION Graph\nNodes 6\nEdges 9\nE 1 2 2\nE 2 3 2\nE 3 4 2\nE 4 5 2\nE 5 6 2\nE 6 1 2\nE 1 4 5\nE 2 5 5\nE 3 6 5\nEND\n"
    paths = []
    for i, terminals in enumerate(("T 1\nT 3\nT 5\n", "T 2\nT 4\nT 6\n")):
        path = folder / ("smoke{}.stp".format(i + 1))
        path.write_text(
            graph + "SECTION Terminals\nTerminals 3\n" + terminals + "END\nEOF\n"
        )
        paths.append(path)
    # This sparse fixture retains enough terminals after reductions to build a MIP.
    rng = random.Random(17)
    edges = []
    for u in range(1, 201):
        for v in range(u + 1, 201):
            if v == u + 1 or rng.random() < 0.02:
                edges.append("E {} {} {}".format(u, v, rng.randint(1, 100)))
    paths[1].write_text(
        "SECTION Graph\nNodes 200\nEdges {}\n".format(len(edges))
        + "\n".join(edges)
        + "\nEND\nSECTION Terminals\nTerminals 20\n"
        + "\n".join("T {}".format(i) for i in range(1, 21))
        + "\nEND\nEOF\n"
    )
    pc = folder / "smoke-pc.stp"
    pc.write_text(
        graph + "SECTION Terminals\nTerminals 3\nTP 1 10\nTP 3 10\nTP 5 10\nEND\nEOF\n"
    )
    return paths, pc


def stp_cases(paths, dataset):
    optima = load_optima()
    result = []
    for path in paths:
        optimum = optimum_for(path.name, optima)
        result.append(
            dict(
                instance=path.name,
                path=str(path.resolve()),
                dataset=dataset,
                instance_sha256=file_hash(path),
                reference_lower=optimum,
                reference_upper=optimum,
            )
        )
    return result


def make_cases(args, output, source):
    if args.smoke:
        paths, pc = fixture_data(output)
        trees = stp_cases(paths, "synthetic-smoke")
        pace = [
            dict(
                trees[0],
                track=t,
                split="synthetic",
                reference_lower=8.0,
                reference_upper=8.0,
            )
            for t in (1, 2, 3)
        ]
        prizes = stp_cases([pc], "synthetic-smoke")
    else:
        if not all((args.pace, args.steinlib, args.pcstp)):
            raise ValueError(
                "full prepare requires --pace, --steinlib (B/ and C/), --pcstp"
            )
        pace = [
            dict(c, dataset="PACE2018")
            for c in reference_cases(args.pace.resolve(), [1, 2, 3])
        ]
        trees = []
        for series, count in (("B", 18), ("C", 20)):
            paths = sorted((args.steinlib / series).glob("*.stp"))
            expected = {
                "{}{:02}".format(series.lower(), i) for i in range(1, count + 1)
            }
            if {p.stem.lower() for p in paths} != expected:
                raise ValueError(
                    "require the complete SteinLib {} series ({} instances)".format(
                        series, count
                    )
                )
            trees += stp_cases(paths, series)
        paths = sorted(args.pcstp.glob("*.stp"))
        if not paths:
            raise ValueError("no JMP .stp instances in --pcstp")
        prizes = stp_cases(paths, "JMP")
    cases = []

    def add(case, experiment, method, solver="none", repeat=0, unit=None):
        item = dict(
            case,
            experiment=experiment,
            method=method,
            solver=solver,
            repeat=repeat,
            seed=0,
            source_root=str(source.resolve()),
        )
        item["case_id"] = digest(item)[:24]
        item["unit_id"] = unit or item["case_id"]
        cases.append(item)

    for case in pace:
        for solver in args.solvers:
            add(case, "pace", "exact", solver)
        add(case, "pace", "heuristic", "highs")
    for index, case in enumerate(pace + trees):
        for solver in args.solvers:
            for repeat in range(args.parity_repeats):
                unit = digest([case, solver, repeat])[:24]
                methods = (
                    ("legacy", "modular")
                    if (index + repeat) % 2 == 0
                    else ("modular", "legacy")
                )
                for method in methods:
                    add(case, "api_parity", method, solver, repeat, unit)
    for case in trees:
        for method in ("kou", "mehlhorn"):
            add(case, "steinlib", method)
        for solver in args.solvers:
            for method in ("exact", "dual_ascent"):
                add(case, "steinlib", method, solver)
        add(case, "steinlib", "heuristic", "highs")
    for case in prizes:
        for solver in args.solvers:
            add(case, "pcstp", "exact", solver)
        add(case, "pcstp", "heuristic", "highs")
        add(case, "pcstp", "pcst_fast")
    return cases


def prepare(args, output):
    with file_lock(output / ".prepare.lock"):
        if (output / "manifest.json").exists():
            raise ValueError(
                "campaign already prepared; use run to resume (or a new --output)"
            )
        installed = versions()
        required = {"steinerpy", "networkx", "numpy", "scipy", "highspy"}
        if "gurobi" in args.solvers:
            required.add("gurobipy")
        if not args.smoke:
            required.add("pcst_fast")
            if sys.platform != "linux" or set(args.solvers) != {"highs", "gurobi"}:
                raise ValueError("full campaign requires Linux and both highs,gurobi")
        if installed["steinerpy"] != "1.1.0" or any(not installed[p] for p in required):
            raise ValueError(
                "install tagged SteinerPy 1.1.0 and required dependencies: "
                + repr(installed)
            )
        source, hashes = source_export(output)
        cases = make_cases(args, output, source)
        manifest = dict(
            schema=1,
            mode="smoke" if args.smoke else "full",
            tag=TAG,
            commit=COMMIT,
            created_utc=now(),
            source_files=hashes,
            source_root=str(source.resolve()),
            harness=harness_hashes(),
            software=software(),
            cases=cases,
            settings=dict(
                time_limit=args.time_limit,
                memory_gb=args.memory_gb,
                threads=1,
                seed=0,
                parity_repeats=args.parity_repeats,
                solvers=args.solvers,
                decompose=False,
                dw_max_terminals=10,
                worker_environment=WORKER_ENV,
            ),
        )
        write_json(output / "manifest.json", manifest)
        write_json(
            output / "environment.json",
            dict(
                tag=TAG,
                commit=COMMIT,
                mode=manifest["mode"],
                prepared_utc=now(),
                software=manifest["software"],
                settings=manifest["settings"],
                environments="environments/*.json",
                note="Compute-node hardware and allocation are recorded separately per environment_id in every result.",
            ),
        )
        frozen = sorted(
            "{}=={}".format(d.metadata["Name"], d.version)
            for d in metadata.distributions()
            if d.metadata["Name"]
        )
        (output / "requirements.freeze.txt").write_text("\n".join(frozen) + "\n")
        from benchmarks.release_report import summarize

        summarize(output)
        print("Prepared {} cases at {}".format(len(cases), output))


def units(manifest):
    groups = {}
    for case in manifest["cases"]:
        groups.setdefault(case["unit_id"], []).append(case)
    return list(groups.values())


def result_path(output, case):
    return output / case["experiment"] / "raw" / case["case_id"] / "result.json"


def verify_campaign(manifest):
    if manifest["commit"] != COMMIT or manifest["tag"] != TAG:
        raise ValueError("wrong release manifest")
    if harness_hashes() != manifest["harness"]:
        raise ValueError("benchmark harness changed; use a new output directory")
    if software() != manifest["software"]:
        raise ValueError(
            "Python or solver/dependency versions changed; use a new output directory"
        )
    verify_source(Path(manifest["source_root"]), manifest["source_files"])


def run(args, output):
    manifest = read_json(output / "manifest.json")
    verify_campaign(manifest)
    env = environment(manifest)
    environment_id = digest(env)[:24]
    envpath = output / "environments" / (environment_id + ".json")
    with file_lock(output / ".environment.lock"):
        envpath.parent.mkdir(exist_ok=True)
        if not envpath.exists():
            write_json(
                envpath, dict(env, environment_id=environment_id, recorded_utc=now())
            )
    settings = manifest["settings"]
    identity = dict(
        env,
        environment_id=environment_id,
        hostname=platform.node(),
        timestamp=now(),
        slurm_job=os.environ.get("SLURM_JOB_ID"),
        slurm_array_job=os.environ.get("SLURM_ARRAY_JOB_ID"),
        slurm_array_task=os.environ.get("SLURM_ARRAY_TASK_ID"),
        **settings,
    )

    def run_unit(group):
        for case in group:
            dest = result_path(output, case)
            with file_lock(dest.parent / "case.lock"):
                if dest.exists():
                    old = read_json(dest)
                    if old.get("case_id") != case["case_id"] or old.get("run", {}).get(
                        "manifest_sha256"
                    ) != digest(manifest):
                        raise ValueError(
                            "result does not match this campaign: " + str(dest)
                        )
                    continue
                if file_hash(case["path"]) != case["instance_sha256"]:
                    raise ValueError("instance changed since prepare: " + case["path"])
                config = (
                    "heuristic" if case["method"] == "heuristic" else case["solver"]
                )
                options = argparse.Namespace(
                    config=config,
                    time_limit=settings["time_limit"],
                    memory_gb=settings["memory_gb"],
                    source_root=manifest["source_root"],
                    worker_script=ROOT / "benchmarks" / "release_worker.py",
                    worker_env=WORKER_ENV,
                )
                with ExitStack() as stack:
                    leases = []
                    if case["solver"] == "gurobi":
                        if os.name == "nt":
                            raise ValueError(
                                "Gurobi campaign workers require the POSIX WLS guard; run on Linux"
                            )
                        # DA may build a second environment on its unchanged release fallback path.
                        with file_lock(
                            args.license_slots / "campaign-acquisition.lock"
                        ):
                            for _ in range(2 if case["method"] == "dual_ascent" else 1):
                                leases.append(
                                    stack.enter_context(
                                        wls_slot(
                                            args.license_slots, settings["time_limit"]
                                        )
                                    )
                                )
                    # Waiting for a second slot can outlive the first reservation.
                    for lease in leases:
                        lease["refresh"]()
                    execute_case(
                        case,
                        options,
                        dict(identity, config=config),
                        dest.parent,
                        dest,
                        case["case_id"],
                    )

    selected = units(manifest)[args.shard_index :: args.shard_count]
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        list(pool.map(run_unit, selected))
    if args.shard_count == 1:
        from benchmarks.release_report import summarize

        with file_lock(output / ".summary.lock"):
            summarize(output)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("export-source", "prepare", "run", "pending", "summarize")
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--pace", type=Path)
    parser.add_argument("--steinlib", type=Path)
    parser.add_argument("--pcstp", type=Path)
    parser.add_argument("--solvers", default=None)
    parser.add_argument("--time-limit", type=float)
    parser.add_argument("--memory-gb", type=float, default=8)
    parser.add_argument("--parity-repeats", type=int)
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--shard-count", type=int, default=1)
    parser.add_argument(
        "--license-slots", type=Path, default=Path.home() / ".cache" / "steinerpy-wls"
    )
    args = parser.parse_args(argv)
    args.solvers = (args.solvers or ("highs" if args.smoke else "highs,gurobi")).split(
        ","
    )
    args.time_limit = (
        args.time_limit if args.time_limit is not None else (30 if args.smoke else 1800)
    )
    args.parity_repeats = (
        args.parity_repeats
        if args.parity_repeats is not None
        else (2 if args.smoke else 3)
    )
    if (
        not 0 <= args.shard_index < args.shard_count
        or not 1 <= args.jobs <= 12
        or args.parity_repeats < 1
        or not math.isfinite(args.time_limit)
        or args.time_limit <= 0
        or not math.isfinite(args.memory_gb)
        or args.memory_gb <= 0
        or not set(args.solvers) <= {"highs", "gurobi"}
        or len(set(args.solvers)) != len(args.solvers)
    ):
        parser.error("invalid limits, solvers, repeats, jobs, or shard index/count")
    output = (args.output or (RELEASE / "smoke" if args.smoke else RELEASE)).resolve()
    if not output.is_relative_to(RELEASE.resolve()):
        parser.error("all campaign output must be under " + str(RELEASE))
    output.mkdir(parents=True, exist_ok=True)
    if args.command == "export-source":
        with file_lock(output / ".prepare.lock"):
            source, _ = source_export(output)
        print(source)
    elif args.command == "prepare":
        prepare(args, output)
    elif args.command == "run":
        run(args, output)
    elif args.command == "pending":
        pending = set()
        for index, group in enumerate(units(read_json(output / "manifest.json"))):
            if any(not result_path(output, case).exists() for case in group):
                pending.add(index % args.shard_count)
        print(",".join(map(str, sorted(pending))))
    else:
        from benchmarks.release_report import summarize

        with file_lock(output / ".summary.lock"):
            summarize(output)


if __name__ == "__main__":
    main()
