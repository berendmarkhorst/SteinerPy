"""Fresh-process release adapters; all measured code is imported from the tag."""

import argparse
from importlib import metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import time


def _write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def _source_imports(source_root):
    """Do not let the controller checkout or an editable install win imports."""
    source_root = Path(source_root).resolve()
    harness_root = Path(__file__).resolve().parents[1]
    sys.path[:] = [
        str(source_root),
        *[
            p
            for p in sys.path
            if Path(p or os.getcwd()).resolve()
            not in {harness_root, harness_root / "benchmarks", source_root}
        ],
    ]
    for name in list(sys.modules):
        if name in {"steinerpy", "benchmarks", "benchmark_pcstp"} or name.startswith(
            ("steinerpy.", "benchmarks.")
        ):
            del sys.modules[name]
    import steinerpy
    from benchmarks import pace2018, stp_parser

    for module in (steinerpy, pace2018, stp_parser):
        if source_root not in Path(module.__file__).resolve().parents:
            raise RuntimeError("Import escaped release snapshot: " + module.__file__)
    installed = metadata.version("steinerpy")
    if installed != "1.1.0" or steinerpy.__version__ != "1.1.0":
        raise RuntimeError("Install the v1.1.0 snapshot before running the campaign")
    return steinerpy, pace2018, stp_parser


def _pcst_helpers(source_root, require_fast):
    """Load the tag's scoring helper even if its optional competitor is absent."""
    missing = importlib.util.find_spec("pcst_fast") is None
    if missing and require_fast:
        raise ModuleNotFoundError("Optional competitor pcst_fast is not installed")
    if missing:
        # The tagged script imports pcst_fast eagerly, including for pure scoring.
        # This placeholder is never used to solve and is removed after import.
        import types

        sys.modules["pcst_fast"] = types.ModuleType("pcst_fast")
    try:
        import benchmark_pcstp
    finally:
        if missing:
            sys.modules.pop("pcst_fast", None)
    if (
        Path(source_root).resolve()
        not in Path(benchmark_pcstp.__file__).resolve().parents
    ):
        raise RuntimeError("PCSTP helper escaped release snapshot")
    return benchmark_pcstp


def validate_pcstp(graph, prizes, edges, nodes, objective, objective_function):
    """Independently check an unrooted tree and its original forgo-prize cost."""
    import networkx as nx

    if not math.isfinite(objective):
        raise ValueError("non-finite objective")
    if len(set(nodes)) != len(nodes) or not set(nodes) <= set(graph):
        raise ValueError("invalid or duplicated selected node")
    tree = nx.Graph()
    tree.add_nodes_from(nodes)
    for u, v in edges:
        if (
            u not in tree
            or v not in tree
            or not graph.has_edge(u, v)
            or tree.has_edge(u, v)
        ):
            raise ValueError("invalid or duplicated original edge")
        tree.add_edge(u, v)
    if tree and not nx.is_tree(tree):
        raise ValueError("PCSTP solution is disconnected or cyclic")
    actual = objective_function(graph, sum(prizes.values()), prizes, edges, nodes)
    if not math.isclose(actual, objective, rel_tol=1e-9, abs_tol=1e-6):
        raise ValueError("reported objective differs from original PCSTP cost")
    return actual


def _timed_builders(objects, row, checkpoint):
    def wrap(original, gurobi):
        def build(*args, **kwargs):
            row.update(phase="model_build", gurobi_started=gurobi)
            checkpoint()
            started = time.perf_counter()
            try:
                return original(*args, **kwargs)
            finally:
                row["model_build_seconds"] += time.perf_counter() - started
                row["model_build_calls"] += 1
                row["phase"] = "solve"
                checkpoint()

        return build

    row.update(model_build_seconds=0.0, model_build_calls=0)
    objects.build_model = wrap(objects.build_model, False)
    objects.build_model_gurobi = wrap(objects.build_model_gurobi, True)


def _tree_case(request, row, package, pace, parser, checkpoint):
    from steinerpy import objects

    graph, groups = parser.read_stp(row["path"])
    row.update(
        nodes=len(graph), edges=graph.number_of_edges(), terminals=len(groups[0])
    )
    method = row["method"]
    gap = math.inf
    if method in {"kou", "mehlhorn"}:
        from networkx.algorithms.approximation import steiner_tree

        row["phase"] = "solve"
        checkpoint()
        started = time.perf_counter()
        tree = steiner_tree(graph, groups[0], weight="weight", method=method)
        row["total_seconds"] = time.perf_counter() - started
        edges, objective = list(tree.edges()), float(tree.size(weight="weight"))
        row.update(
            constructor_seconds=None, model_build_seconds=None, solver_seconds=None
        )
    else:
        _timed_builders(objects, row, checkpoint)
        row["phase"] = "construct"
        checkpoint()
        started = time.perf_counter()
        options = dict(preprocess=True, dual_ascent=method == "dual_ascent")
        problem = (
            package.Problem(graph, terminals=groups[0], **options)
            if method == "modular"
            else package.SteinerProblem(graph, groups, **options)
        )
        row["constructor_seconds"] = time.perf_counter() - started
        row["phase"] = "solve"
        checkpoint()
        solution = problem.get_solution(
            time_limit=request["time_limit"],
            solver=row["solver"] if row["solver"] != "none" else "highs",
            threads=1,
            decompose=False,
            exact=method != "heuristic",
        )
        row["total_seconds"] = time.perf_counter() - started
        row["solver_seconds"] = float(solution.runtime)
        row["solver_seconds_definition"] = (
            "Solution.runtime (solver loop or non-MIP exact/heuristic path)"
        )
        edges, objective, gap = (
            list(solution.edges),
            float(solution.objective),
            float(solution.gap),
        )
    row.update(
        objective=objective if math.isfinite(objective) else None,
        gap=gap if math.isfinite(gap) else None,
        solution_edges=edges,
    )
    lower = row.get("reference_lower")
    upper = row.get("reference_upper")
    checked = pace.validate_solution(
        graph,
        groups[0],
        edges,
        objective,
        gap,
        0.0 if lower is None else lower,
        math.inf if upper is None else upper,
    )
    if upper is None:
        checked["reference_ratio"] = None
    row.update(checked)
    row["solution_nodes"] = sorted(set(groups[0]) | {n for edge in edges for n in edge})


def _pcstp_case(request, row, package, parser, checkpoint):
    helper = _pcst_helpers(row["source_root"], row["method"] == "pcst_fast")
    graph, prizes = parser.read_pcspg(row["path"])
    row.update(
        nodes=len(graph),
        edges=graph.number_of_edges(),
        terminals=len(prizes),
        phase="solve",
    )
    checkpoint()
    started = time.perf_counter()
    gap = math.inf
    if row["method"] == "pcst_fast":
        # Capture the unchanged helper's certificate without duplicating its adapter.
        original = helper.pcst_fast.pcst_fast
        certificate = {}

        def capture(*args, **kwargs):
            selected_nodes, selected_edges = original(*args, **kwargs)
            all_nodes, all_edges = sorted(graph.nodes()), list(graph.edges())
            certificate["nodes"] = [all_nodes[int(i)] for i in selected_nodes]
            certificate["edges"] = [all_edges[int(i)] for i in selected_edges]
            return selected_nodes, selected_edges

        helper.pcst_fast.pcst_fast = capture
        try:
            objective, runtime = helper.run_pcst_fast(
                graph, prizes, sum(prizes.values())
            )
        finally:
            helper.pcst_fast.pcst_fast = original
        edges, nodes = certificate["edges"], certificate["nodes"]
        row.update(
            constructor_seconds=None,
            solver_seconds=runtime,
            solver_seconds_definition="pcst_fast kernel",
        )
    else:
        root = max(prizes, key=prizes.get)
        problem = package.PrizeCollectingProblem(
            graph.copy(),
            [[root]],
            prizes,
            weight="weight",
            penalty_cost=0,
        )
        row["constructor_seconds"] = time.perf_counter() - started
        row["gurobi_started"] = row["solver"] == "gurobi"
        checkpoint()
        solution = problem.get_solution(
            pc_transform=True,
            exact=row["method"] != "heuristic",
            time_limit=request["time_limit"],
            threads=1,
            solver=row["solver"] if row["solver"] != "none" else "highs",
        )
        edges, nodes = list(solution.edges), list(solution.selected_nodes)
        gap = float(solution.gap)
        objective = helper.pcstp_objective(
            graph, sum(prizes.values()), prizes, edges, nodes
        )
        reported = float(solution.objective)
        row.update(
            reported_objective=reported if math.isfinite(reported) else None,
            solver_seconds=None,
            reported_solution_seconds=float(solution.runtime),
            solver_seconds_definition="unavailable separately: transform and DA included in Solution.runtime",
        )
    row.update(
        total_seconds=time.perf_counter() - started,
        model_build_seconds=None,
        objective=float(objective),
        gap=gap if math.isfinite(gap) else None,
        solution_edges=edges,
        solution_nodes=nodes,
    )
    validate_pcstp(
        graph,
        prizes,
        edges,
        nodes,
        reported if row["method"] != "pcst_fast" else objective,
        helper.pcstp_objective,
    )
    row.update(
        feasible=True,
        solver_proven_optimal=gap == 0,
        status="optimal" if gap == 0 else "feasible",
    )


def worker(request_path):
    request = json.loads(Path(request_path).read_text())
    row = dict(request["case"])
    progress = Path(request["progress"])
    started = time.monotonic()
    row.update(status="running", phase="imports", feasible=False, gurobi_started=False)
    checkpoint = lambda: _write_json(progress, row)
    checkpoint()
    try:
        if sys.platform == "linux":
            import resource

            bound = int(request["memory_gb"] * 1024**3)
            resource.setrlimit(resource.RLIMIT_AS, (bound, bound))
        package, pace, parser = _source_imports(row["source_root"])
        import logging
        import random
        import numpy as np

        logging.disable(logging.CRITICAL)
        seed = row.get("seed", 0)
        random.seed(seed)
        np.random.seed(seed)
        if row["experiment"] == "pace":
            pace.worker(request_path)
            result = json.loads(progress.read_text())
            result["total_seconds"] = result.get("preprocess_seconds", 0) + result.get(
                "solve_seconds", 0
            )
            result["constructor_seconds"] = result.get("preprocess_seconds")
            result["steinerpy_import_path"] = str(Path(package.__file__).resolve())
            result["steinerpy_version"] = package.__version__
            _write_json(progress, result)
            return
        row.update(
            steinerpy_import_path=str(Path(package.__file__).resolve()),
            steinerpy_version=package.__version__,
        )
        if row["solver"] == "gurobi" and importlib.util.find_spec("gurobipy") is None:
            raise ModuleNotFoundError("Optional backend gurobipy is not installed")
        if row["experiment"] == "pcstp":
            _pcstp_case(request, row, package, parser, checkpoint)
        else:
            _tree_case(request, row, package, pace, parser, checkpoint)
        row.update(
            phase="complete",
            optimality_status=(
                "proven_optimal"
                if row.get("solver_proven_optimal")
                else "reference_optimal" if row.get("reference_optimal") else "unproven"
            ),
        )
    except MemoryError:
        row.update(status="memory_limit", feasible=False, error="MemoryError")
    except (ModuleNotFoundError, metadata.PackageNotFoundError) as error:
        row.update(status="unavailable", feasible=False, error=str(error))
    except Exception as error:
        row.update(
            status="error",
            feasible=False,
            error="{}: {}".format(type(error).__name__, error),
        )
    row["worker_seconds"] = time.monotonic() - started
    if sys.platform != "win32":
        import resource

        row["peak_rss_mb"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (
            1024 if sys.platform != "darwin" else 1024**2
        )
    checkpoint()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", required=True)
    worker(parser.parse_args().worker)
