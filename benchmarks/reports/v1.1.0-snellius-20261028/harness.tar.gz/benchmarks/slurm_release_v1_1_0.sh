#!/usr/bin/env bash
# Submit from the checkout containing this harness; measured code comes from v1.1.0.
set -euo pipefail

MODE="${1:-submit}"
if [[ $# -gt 0 ]]; then shift; fi

case "$MODE" in
    worker)
        HARNESS="$1" OUTPUT="$2" PYTHON="$3" SHARDS="$4" JOBS="$5"
        export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
        export NUMEXPR_NUM_THREADS=1 STEINERPY_THREADS=1 PYTHONHASHSEED=0
        export STEINERPY_DECOMPOSE=0 STEINERPY_DW_MAX_TERMINALS=10
        exec "$PYTHON" "$HARNESS" run --output "$OUTPUT" \
            --shard-index "${SLURM_ARRAY_TASK_ID:?Expected a Slurm array task}" \
            --shard-count "$SHARDS" --jobs "$JOBS"
        ;;
    summary)
        exec "$3" "$1" summarize --output "$2"
        ;;
    submit|resume) ;;
    *)
        echo "Usage: bash benchmarks/slurm_release_v1_1_0.sh submit|resume [--account=NAME] [--qos=NAME] [--reservation=NAME]" >&2
        exit 2
        ;;
esac

for OPTION in "$@"; do
    case "$OPTION" in
        --account=?*|--qos=?*|--reservation=?*) ;;
        *)
            echo "Only --account=NAME, --qos=NAME and --reservation=NAME overrides are supported: $OPTION" >&2
            exit 2
            ;;
    esac
done

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/$(basename -- "${BASH_SOURCE[0]}")"
HARNESS="$SCRIPT_DIR/release_campaign.py"
OUTPUT="${CAMPAIGN_OUTPUT:-$SCRIPT_DIR/releases/v1.1.0}"
PYTHON="${CAMPAIGN_PYTHON:-python}"
PYTHON="$("$PYTHON" -c 'import sys; print(sys.executable)')"
OUTPUT="$("$PYTHON" -c 'import pathlib,sys; print(pathlib.Path(sys.argv[1]).resolve())' "$OUTPUT")"
SHARDS="${CAMPAIGN_SHARDS:-64}"
JOBS="${CAMPAIGN_JOBS:-3}"
CONCURRENCY="${CAMPAIGN_CONCURRENCY:-4}"
for VALUE in "$SHARDS" "$JOBS" "$CONCURRENCY"; do
    if [[ ! "$VALUE" =~ ^[1-9][0-9]*$ ]]; then
        echo "Shards, jobs and concurrency must be positive integers" >&2
        exit 2
    fi
done
if (( JOBS > 3 || CONCURRENCY * JOBS > 12 )); then
    echo "At most 3 workers per 28 GiB allocation and 12 workers across arrays are supported" >&2
    exit 2
fi
if [[ ! -f "$OUTPUT/manifest.json" ]]; then
    echo "Prepare the campaign first: $PYTHON $HARNESS prepare --pace PATH --steinlib PATH --pcstp PATH" >&2
    exit 2
fi

if [[ "$MODE" == resume ]]; then
    INDICES="$("$PYTHON" "$HARNESS" pending --output "$OUTPUT" --shard-count "$SHARDS")"
else
    INDICES="0-$((SHARDS - 1))"
fi
if [[ -z "$INDICES" ]]; then
    echo "No incomplete cases; regenerating summaries."
    exec "$PYTHON" "$HARNESS" summarize --output "$OUTPUT"
fi

mkdir -p "$OUTPUT/logs"
export CAMPAIGN_SLURM_WALLTIME=24:00:00
# Keep these paths as script arguments: Slurm executes a copy in its spool directory.
ARRAY_JOB="$(sbatch --parsable --job-name=steinerpy-v1.1.0 \
    --partition=rome --nodes=1 --ntasks=1 --cpus-per-task=16 --mem=28G \
    --time=24:00:00 --array="$INDICES%$CONCURRENCY" \
    --output="$OUTPUT/logs/campaign-%A_%a.log" "$@" \
    "$SCRIPT" worker "$HARNESS" "$OUTPUT" "$PYTHON" "$SHARDS" "$JOBS")"
ARRAY_JOB="${ARRAY_JOB%%;*}"
SUMMARY_JOB="$(sbatch --parsable --job-name=steinerpy-v1.1.0-summary \
    --partition=rome --nodes=1 --ntasks=1 --cpus-per-task=16 --mem=28G \
    --time=00:30:00 --dependency="afterany:$ARRAY_JOB" \
    --output="$OUTPUT/logs/summary-%j.log" "$@" \
    "$SCRIPT" summary "$HARNESS" "$OUTPUT" "$PYTHON")"
printf 'Campaign array: %s\nSummary job: %s\nOutput: %s\n' "$ARRAY_JOB" "${SUMMARY_JOB%%;*}" "$OUTPUT"
